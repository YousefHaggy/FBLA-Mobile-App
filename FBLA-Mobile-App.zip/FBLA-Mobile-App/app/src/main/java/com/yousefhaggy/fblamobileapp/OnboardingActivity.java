package com.yousefhaggy.fblamobileapp;

import android.graphics.Color;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import com.ramotion.paperonboarding.PaperOnboardingFragment;
import com.ramotion.paperonboarding.PaperOnboardingPage;

import java.util.ArrayList;

public class OnboardingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding);
        //Onboarding View
        PaperOnboardingPage scr= new PaperOnboardingPage("Home","Do bla bla", Color.RED,R.drawable.ic_home,R.drawable.ic_home);
        PaperOnboardingPage scr2= new PaperOnboardingPage("Home 2","Do bla bla",Color.GREEN,R.drawable.ic_home,R.drawable.ic_home);
        ArrayList<PaperOnboardingPage> pages= new ArrayList<>();
        PaperOnboardingFragment onboardingFragment=PaperOnboardingFragment.newInstance(pages);
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.add(R.id.onboardingFragmentView,onboardingFragment);
        fragmentTransaction.commit();

    }
}
